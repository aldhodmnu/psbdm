<!DOCTYPE html>
<html lang="id">

<!-- heading -->
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- import file css bootstrap -->
    <link rel="stylesheet" href="styles/bootstrap/css/bootstrap.min.css">
    
    <!-- import file css DataTables -->
    <link rel="stylesheet" href="styles/DataTables/datatables.min.css">

    <!-- Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    
    <!-- Title -->
    <title>Penerimaan Santri Baru Pontren Darul Ma'arif Kaplongan-Indramayu<?php echo $header ;?></title>
    <!-- Favicon -->
    
    <link rel="icon" type="image/x-icon" href="https://daftar.darulmaarif.net/assets/img/logo.png" />
</head>

<!-- body fa-swatchbook-->

<body>
    
    <!-- header  <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-5">--> 
<!--<nav class="navbar navbar-light bg-lignt"> --> 

   <div class="card my-14 o-hidden border-0 shadow-lg">
 <nav class="navbar navbar-expand-lg navbar-light bg-lignt px-5">
        
        <a class="navbar-brand" href="index.php"><i class="fa fa-home"></i><font color="green"> Home</font> </font> </a>
        
    
         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- menu navigasi -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            
            <ul class="navbar-nav mr-auto">
                <?php

                // fungsi pengecekan level akun login
                if(empty($_SESSION['sesi'])){
                    echo "";
                } elseif($_SESSION['type'] == 'admin') {
                    echo '
                    <li class="nav-item">
                     <a class="nav-link" href="dashboard.php"><i class="fas fa-desktop"></i><font color="green">  Dasboard <span class="sr-only">(current)</span></font></a>
                    </li>
                    <li class="nav-item">
                     <a class="nav-link" href="biayadu.php"><i class="far fa-calendar-check"></i><font color="green">  Biaya Daftar Ulang <span class="sr-only">(current)</span></font></a>
                    </li>
                    <li class="nav-item">
                     <a class="nav-link" href="download_index.php"><i class="fa fa-cloud-download"></i><font color="green">  Download <span class="sr-only">(current)</span></font></a>
                    </li>
                        <a class="nav-link" href="pengguna.php"><i class="fas fa-user-friends"></i><font color="green">  Akun <span class="sr-only">(current)</span></font></a>
                    </li>
                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user-edit"></i><font color="green"> 
                        Data Peserta
                        </font></a>
                        <div class="dropdown-menu" color-green aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="siswa_seleksi.php"><i class="fas fa-user-cog"></i> Seleksi</a>
                            <a class="dropdown-item" href="siswa_diterima.php"><i class="fas fa-user-check"></i> Diterima</a>
                           
                            <a class="dropdown-item" href="siswa_ditolak.php"><i class="fas fa-user-times"></i> Tidak Diterima</a>
                        </div>
                    
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i><font color="grey"> Logout</font></a>
                </li>
                    
                    ';

                } 
                  
                else {
                    echo '
                    <li class="nav-item">
                    <a class="nav-link" href="pernyataan.php"><i class="far fa-file-alt"></i><font color="green">  Surat Pernyataan</font></a>
                </li>
                    
                    <li class="nav-item">
                    <a class="nav-link" href="pendaftaran.php"><i class="far fa-edit"></i><font color="green">  Pendaftaran<span class="sr-only">(current)</span></font></a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link" href="status.php"><i class="fas fa-user-clock"></i><font color="green">  Status</font></a>
                </li>
                                    <li class="nav-item">
                     <a class="nav-link" href="biayadu.php"><i class="far fa-calendar-check"></i><font color="green">  Biaya Daftar Ulang <span class="sr-only">(current)</span></font></a>
                    </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i><font color="grey"> Logout</font></a>
                </li>';
                
                }

                ?>
                
            </ul>
 </div>
            <!-- tombol logout -->
           
        </div>
        
    </nav>

    