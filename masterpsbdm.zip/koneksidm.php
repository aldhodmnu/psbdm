
<?php 

$dm=mysqli_connect("103.84.206.51","dm_1","masterkey","dm_1");

if (!$dm)
{
	die("koneksi gagal: " . mysqli_connect_error());
}

?>



