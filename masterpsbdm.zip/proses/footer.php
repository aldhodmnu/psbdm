<!-- Footer container -->
<div class="container-fluid mt-4">

    <!-- Footer text -->
    <p class="text-center text-secondary">
        Penerimaan Santri Baru Online Pondok Pesantren Darul Ma'arif Kaplongan-Indramayu
    </p>
</div>

<!-- fontawesome -->
<script src="https://kit.fontawesome.com/c48877bd36.js" crossorigin="anonymous"></script>

<!-- import jQuery -->
<script type="text/javascript" src="styles/jquery/jquery.min.js"></script>

<!-- import Js Bootstrap -->
<script type="text/javascript" src="styles/bootstrap/js/bootstrap.min.js"></script>

<!-- import DataTables -->
<script type="text/javascript" src="styles/DataTables/datatables.min.js"></script>

<!-- fungsi Setting DataTables -->
<script>
    $(document).ready(function() {
        var table = $('#dataTable').DataTable( {
            responsive: true
        } );
    } );
</script>
</body>
</html>