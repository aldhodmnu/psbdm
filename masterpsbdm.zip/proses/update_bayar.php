<?php

// import file koneksi
include '../koneksi.php';

// inisialisasi variabel id dan status
$id = $_GET['id'];
$status = "DIBAYAR";

// mengubah data status pendaftaran menjadi Tidak Diterima
$query = mysqli_query ($db, "UPDATE pendaftaran SET bayardaftar = '$status' WHERE id ='$id'");
$query2 = mysqli_query ($db, "UPDATE user SET bayardaftar = '$status' WHERE id ='$id'");
//  fungsi pengecekan $query 
if($query){

    // jika berhasil load ke halaman index.php
    echo "<meta http-equiv='refresh' content='0; url=../index.php'>";
}else{

    // jika gagal tampilkan alert Gagal
    echo "<script type='text/javascript'>
    onload =function(){
        alert('Gagal');
    }
    </script>";
}

?>